﻿namespace L6_NICOLASRIVAS_1045123
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1");

            double numero1;
            Console.WriteLine("Ingrese un numero:");
            numero1 = double.Parse(Console.ReadLine());

            double numero2;
            Console.WriteLine("Ingrese otro numero:");
            numero2 = double.Parse(Console.ReadLine());

            double suma = numero1 + numero2;
            double resta = numero1 - numero2;
            double multiplicacion = numero1 * numero2;
            double division = numero1 / numero2;
            double div = (int)(numero1 / numero2);
            double mod = numero1 % numero2;

            Console.WriteLine(suma);
            Console.WriteLine(resta);
            Console.WriteLine(multiplicacion);
            Console.WriteLine(division);
            Console.WriteLine(div);
            Console.WriteLine(mod);

            Console.ReadKey();
        }
    }
}