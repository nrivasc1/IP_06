﻿class Clase_Menu
{
    static void Main(string[] args)
    {
        Console.WriteLine("Dosificación de los horarios de las jornadas laborales");
        Console.WriteLine();
        Console.WriteLine("Seleccione una opcion de menu");
        Console.WriteLine();
        Console.WriteLine("Menú Principal");
        Console.WriteLine("1. Horarios");
        Console.WriteLine("2. Salarios");
        Console.WriteLine("3. Recursos");
        Console.WriteLine("4. Opciones para trabajadores");
        string opcion;
        opcion = Console.ReadLine();

        switch (opcion)
        {
            case "1":
                Console.WriteLine("Usted selecciono: " + opcion + " " + "Horarios");
                break;
            case "2":
                Console.WriteLine("Usted selecciono: " + opcion + " " + "salarios");
                break;
            case "3":
                Console.WriteLine("Usted selecciono: " + opcion + " " + "Recursos");
                break;
            case "4":
                Console.WriteLine("Usted selecciono: " + opcion + " " + "Opciones para trabajadores");
                break;

            default:
                Console.WriteLine("Seleccione una opcion valida");
                break;
        }
        Console.ReadKey();
    }
    
}