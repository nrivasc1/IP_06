﻿namespace L9_NICOLASCASTELLANOS_1045123
{
    internal class Program
    {
        public static double Dmonto;
        public static double contador = 1;
        public static void Main()
        {
            string monto;
            Console.WriteLine("Bienvenido a su tienda de preferencia");
           
            Console.WriteLine("Cual es el monto a pagar");
            monto = Console.ReadLine();

            while (!double.TryParse(monto, out Dmonto))
            {
                Console.WriteLine("ingrese un monto de forma correcta, ejemplo: 0,00");
            }

            calcular(Dmonto);
            
                   
        }
        public static void calcular(double monto)
        {
            contador++;
            if (monto <= 400)
            {
                monto = monto;
            }
        }
    }
}