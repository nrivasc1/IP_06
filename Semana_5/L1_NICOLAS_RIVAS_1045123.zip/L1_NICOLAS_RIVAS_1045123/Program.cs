﻿
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre");
        string Nombre = Console.ReadLine();
        Console.WriteLine("Hola Mundo");
        Console.WriteLine("Soy " + Nombre);
        /*
        Esto es un ejemplo de comentario
        */
        // otros comentarios
        Console.WriteLine("Hola mundo");
        Console.WriteLine("Soy " + Nombre);
        Console.ReadKey();
    }
}