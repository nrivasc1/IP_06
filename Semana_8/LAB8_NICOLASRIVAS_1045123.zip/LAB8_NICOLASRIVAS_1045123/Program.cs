﻿namespace LAB8_NICOLASRIVAS_1045123
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double Dinero;
            double Billetes100 = 0;
            double Billetes50 = 0;
            double Billetes20 = 0;
            double Billetes10 = 0;
            double Billetes5 = 0;
            double Monedas1 = 0;
            double Centavos25 = 0;
            double Centavos1 = 0;

            Console.WriteLine("Nicolas Rivas  -1045123");
            Console.WriteLine("Ingrese una cantidad de Dinero: ");
            Dinero = Convert.ToDouble(Console.ReadLine());

            if (Dinero >= 100)
            {
                Billetes100 = Dinero / 100;
                Dinero = Dinero % 100;
            }

            if (Dinero >= 50)
            {
                Billetes50 = Dinero / 50;
                Dinero = Dinero % 50;

            }

            if (Dinero >= 20)
            {
                Billetes20 = Dinero / 20;
                Dinero = Dinero % 20;
            }

            if (Dinero >= 10)
            {
                Billetes10 = Dinero / 10;
                Dinero = Dinero % 10;
            }

            if (Dinero >= 5)
            {
                Billetes5 = Dinero / 5;
                Dinero = Dinero % 5;
            }

            if (Dinero >= 1)
            {
                Monedas1 = Dinero / 1;
                Dinero = Dinero % 1;
            }

            if (Dinero >= 0.25)
            {
                Centavos25 = Dinero / 0.25;
                Dinero = Dinero % 0.25;
            }

            if (Dinero >= 0.01)
            {
                Centavos1 = Dinero / 0.01;
                Dinero = Dinero % 0.01;
            }

            Console.WriteLine("Usted necesita la siguiente cantidad de billetes:");
            Console.WriteLine(" " + Math.Truncate(Billetes100) + " Billetes de 100");
            Console.WriteLine(" " + Math.Truncate(Billetes50) + " Billetes de 50");
            Console.WriteLine(" " + Math.Truncate(Billetes20) + " Billetes de 20");
            Console.WriteLine(" " + Math.Truncate(Billetes10) + " Billetes de 10");
            Console.WriteLine(" " + Math.Truncate(Billetes5) + " Billetes de 5");
            Console.WriteLine(" " + Math.Truncate(Monedas1) + " Monedas de 1");
            Console.WriteLine(" " + Math.Truncate(Centavos25) + " Monedas de 25");
            Console.WriteLine(" y " + Convert.ToInt32(Centavos1) + " centavos");

            Console.ReadKey();
        }
    }
}
