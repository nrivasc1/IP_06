﻿namespace L7_NICOLASRIVAS_1045123
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1");

            int numero1 = 0;
            Console.WriteLine("Ingrese un numero");
            numero1 = int.Parse(Console.ReadLine());
            if (numero1 > 0)
            {
                Console.WriteLine("El numero ingresado es positivo");
            }
            else if (numero1 < 0)
            {
                Console.WriteLine("El numero ingresado es negativo");
            }
            else if (numero1 == 0)
            {
                Console.WriteLine("El numero ingresado es cero");

            }

            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("ejercicio 2");

            Console.WriteLine("seleccione un dia de la semana");
            string dia;
            dia = Console.ReadLine();
            switch (dia)
            {
                case "1":
                    Console.WriteLine("Dia Lunes");
                break;
                case "2":
                    Console.WriteLine("Dia Martes");
                break;
                case "3":
                    Console.WriteLine("Dia Miercoles");
                break;
                case "4":
                    Console.WriteLine("Dia Jueves");
                break;
                case "5":
                    Console.WriteLine("Dia Viernes");
                break;
                case "6":
                    Console.WriteLine("Dia Sabado");
                break;
                case "7":
                    Console.WriteLine("Dia Domingo");
                break;
                default:
                    Console.WriteLine("Seleccionar un dia valido");
                break;
            }





        }
    }
}